جهان نما - نسخه 1.5.0
این بسته شامل سورس پروژه اندروید است.
برای ساخت APK:
1) پروژه را در Android Studio باز کنید.
2) از منوی Build گزینه Build APK(s) را اجرا کنید.
یا در محیط دارای Android SDK و Gradle اجرا کنید: gradle assembleDebug
خروجی: app/build/outputs/apk/debug/app-debug.apk

نکته: اطلاعات آزمون‌ها و نتایج در این نسخه روی همان دستگاه ذخیره می‌شوند (localStorage).
برای همگام‌سازی چند دستگاه به سرور و API نیاز است.
