package ir.barandehbash.app;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;

public class MainActivity extends Activity {
  private ValueCallback<android.net.Uri[]> uploadCallback;
  private static final int FILE_CHOOSER_REQUEST = 42;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.addJavascriptInterface(new Object(){
      @JavascriptInterface public void shareText(String title, String text) {
        runOnUiThread(() -> {
          Intent send = new Intent(Intent.ACTION_SEND);
          send.setType("text/plain");
          send.putExtra(Intent.EXTRA_SUBJECT, title);
          send.putExtra(Intent.EXTRA_TEXT, text);
          startActivity(Intent.createChooser(send, title));
        });
      }
    }, "AndroidShare");
    w.setWebViewClient(new WebViewClient());
    w.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView webView, ValueCallback<android.net.Uri[]> callback, FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
        uploadCallback=callback;
        Intent intent=params.createIntent();
        try{startActivityForResult(intent,FILE_CHOOSER_REQUEST);}catch(Exception e){uploadCallback=null;return false;}
        return true;
      }
    });
    setContentView(w);
    w.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER_REQUEST&&uploadCallback!=null){
      android.net.Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
      uploadCallback.onReceiveValue(result);uploadCallback=null;
    }
  }
}
